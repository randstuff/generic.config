Skin instructions:

INSTALL
In Yakuake "Appearance" settings choose "Install Skin" and load skin file (no extraction or something like that needed)

NARROWER THAN 100%
For Yakuake widths smaller than 100%, adjust title.skin the following way:
- in [Border] group set "width" to "1"
- in [-Button] groups add 5 to "x" values ("76", "52", "28")
- in [Background] change "left_corner" to "/title/left_nw_tr.png"
... and tabs.skin this way:
- in [Tabs] set "x" to "30"
- in [PlusButton] set "x" to "10"
- in [MinusButton] set "x" to "26"

TRANSPARENCY
To make Yakuake transparent, these steps are required:
- in Yakuake "Appearance" settings set "Background color opacity" to "0%"
- in terminal context menu select "Edit Current Profile...", "Appearance", "Edit" and set "Background transparency" ("0%" no transparency)
